package com.example.walking.model

data class PageListModel (
    var body: List<ItemModel>?
)