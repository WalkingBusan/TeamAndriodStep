package com.example.walking.model

data class User(
    var email:String,
    var password: String,
    var nickname: String
)