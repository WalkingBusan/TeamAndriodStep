package com.example.walking.model

data class LoginDto(
    var email:String,
    var password:String
)
