package com.example.k1109_chc_test.model

data class PageListModel (
    var body: List<ItemModel>?
)